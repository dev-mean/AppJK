-------------------------------------------------------
    Thank you for downloading Tracks!
-------------------------------------------------------
If you need help getting setup, you can find
documentation here:
http://www.competethemes.com/documentation/

If you need further assistance or find any bugs,
please contact us at support@competethemes.com

-------------------------------------------------------
    Licenses:
-------------------------------------------------------

Tracks WordPress Theme, Copyright 2014 Compete Themes
Tracks is distributed under the terms of the GNU GPL

License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Tracks also uses:

* Hybrid Core by Justin Tadlock, http://themehybrid.com/hybrid-core, licensed under the GPL license.
* Fitvids, by Chris Coyier & Dave Ruper, https://github.com/davatron5000/FitVids.js/, licensed under the WTFPL license.
* Placeholders.js by James Allardice, http://jamesallardice.github.io/Placeholders.js/, licensed under the MIT license.
* Google Fonts, http://google.com/fonts, licensed under open source licenses, see: https://developers.google.com/fonts/faq#Any_Page_OK.
* Font Awesome by Dave Gandy, licensed under open source licenses, see: http://fortawesome.github.io/Font-Awesome/license/.
* Picturefill by Scott Jehl, http://scottjehl.github.io/picturefill, licensed under the MIT license.
* All textures in the Background Textures upgrade come from Atle Mo, http://subtlepatterns.com, under the Attribution-ShareAlike 3.0 Creative Commons license: https://creativecommons.org/licenses/by-sa/3.0/us/
* All images in screenshot.png from http://unsplash.com, licensed under Public Domain
